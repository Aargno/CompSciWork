lib_xassert change log
======================

3.0.0
-----

  * CHANGE: Renamed DEBUG_UNIT to XASSERT_UNIT to prevent conflict with
    lib_logging

2.0.1
-----

  * CHANGE: Update to source code license and copyright

2.0.0
-----

  * CHANGE: Restructured library

