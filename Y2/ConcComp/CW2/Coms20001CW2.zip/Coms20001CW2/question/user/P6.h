#ifndef __P6_H
#define __P6_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "libc.h"

#endif